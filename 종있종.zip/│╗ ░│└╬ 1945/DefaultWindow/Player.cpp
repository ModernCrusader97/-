#include "stdafx.h"
#include "Player.h"
#include "Bullet.h"
#include "Laser.h"

CPlayer::CPlayer()
{
	ZeroMemory(&m_tBarrel, sizeof(POINT));
}


CPlayer::~CPlayer()
{
	Release();
}

void CPlayer::Initialize(void)
{
	m_tInfo = { 400.f, 500.f, 50.f, 50.f };
	m_fSpeed = 5.f;
	m_fDistance = 50.f;
	m_fAngle = 90;
	m_iFireRate = 0;
	m_iLasorRate = 0;
	m_iLasorUpgrade = 0;
}

int CPlayer::Update(void)
{
	if (m_bDead == true)
	{
		m_iLasorUpgrade--;
		m_bDead = false;
	}
	if (m_iLasorUpgrade <0)
	{

		return 1;
	}




	Key_Input();



	
	__super::Update_Rect();

	return 0;
}
void CPlayer::LateUpdate(void)
{
	m_tBarrel.x = LONG(m_tInfo.fX + (m_fDistance * cos(m_fAngle * (3.141592 / 180.f))));
	m_tBarrel.y = LONG(m_tInfo.fY - (m_fDistance * sin(m_fAngle * (3.141592 / 180.f))));
}
void CPlayer::Render(HDC hDC)
{
	Ellipse(hDC, m_tRect.left, m_tRect.top, m_tRect.right, m_tRect.bottom);
	TCHAR	szBuf[32] = L"Spider-Man";
	DrawText(hDC, szBuf, lstrlen(szBuf), &m_tRect, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_NOCLIP);
	MoveToEx(hDC, (int)m_tInfo.fX, (int)m_tInfo.fY, nullptr);
	LineTo(hDC, m_tBarrel.x, m_tBarrel.y);
}

void CPlayer::Release(void)
{
}



void CPlayer::Key_Input(void)
{
	
	//GetKeyState()
	if (GetAsyncKeyState(VK_RIGHT))
	{
	if(GetAsyncKeyState(VK_UP))
	{
	m_tInfo.fX += m_fSpeed / sqrtf(2.f);
	m_tInfo.fY -= m_fSpeed / sqrtf(2.f);
	}
	else if (GetAsyncKeyState(VK_DOWN))
	{
	m_tInfo.fX += m_fSpeed / sqrtf(2.f);
	m_tInfo.fY += m_fSpeed / sqrtf(2.f);
	}
	else
	m_tInfo.fX += m_fSpeed;
	}


	else if (GetAsyncKeyState(VK_LEFT))
	{
	if (GetAsyncKeyState(VK_UP))
	{
	m_tInfo.fX -= m_fSpeed / sqrtf(2.f);
	m_tInfo.fY -= m_fSpeed / sqrtf(2.f);
	}
	else if (GetAsyncKeyState(VK_DOWN))
	{
	m_tInfo.fX -= m_fSpeed / sqrtf(2.f);
	m_tInfo.fY += m_fSpeed / sqrtf(2.f);
	}
	else
	m_tInfo.fX -= m_fSpeed;
	}


	else if (GetAsyncKeyState(VK_UP))
	m_tInfo.fY -= m_fSpeed;

	else if (GetAsyncKeyState(VK_DOWN))
	m_tInfo.fY += m_fSpeed;

	if (GetAsyncKeyState(VK_SPACE))
	{
		if (m_iFireRate == 5)
		{
			m_pBullet->push_back(CreateBullet());
			m_iFireRate = 0;
		}
		if (m_iLasorRate == 50)
		{
			for (int i = 0; m_iLasorUpgrade > i; i++)
			{
				m_pLasor->push_back(CreateLasor(i+1));
				m_pLasor->push_back(CreateLasor(-i-1));
			}
			m_iLasorRate = 0;
		}
		m_iLasorRate++;
		m_iFireRate++;
		
	}
	/*if (GetAsyncKeyState('Q'))
		m_fAngle += 5.f;*/
	if (GetAsyncKeyState('W'))
	{
		m_tInfo.fX += m_fSpeed * cos(m_fAngle * (3.141592 / 180.f));
		m_tInfo.fY -= (m_fSpeed * sin(m_fAngle * (3.141592 / 180.f)));
	}
	/*if (GetAsyncKeyState('E'))
		m_fAngle -= 5.f;*/
}

 CObj* CPlayer:: CreateBullet()
{
	CObj* pBullet = new CBullet;
	pBullet->Initialize();
	pBullet->SetPos(m_tBarrel.x, m_tBarrel.y);
	pBullet->SetAngle(m_fAngle);
	return pBullet;
}
 CObj* CPlayer::CreateLasor(int _iUpgrade)
 {
	 CObj* pBullet = new CLaser;
	 pBullet->Initialize();
	 pBullet->SetPos(m_tBarrel.x + _iUpgrade*25, m_tBarrel.y);
	 pBullet->SetAngle(m_fAngle);
	 return pBullet;
 }