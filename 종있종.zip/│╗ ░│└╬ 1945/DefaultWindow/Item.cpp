#include "stdafx.h"
#include "Item.h"


CItem::CItem()
{
}


CItem::~CItem()
{
	Release();
}

void CItem::Initialize(void)
{
	m_tInfo.fCX = 50.f;
	m_tInfo.fCY = 20.f;
	m_fSpeed = 1.f;
	m_iLife = 5;
	m_fAngle = 245;
	m_bDead = false;
}

int CItem::Update(void)
{

	if (m_bDead == true)
		return 1;


	m_tInfo.fX += m_fSpeed * cos(m_fAngle * (3.141592 / 180.f));
	m_tInfo.fY -= (m_fSpeed * sin(m_fAngle * (3.141592 / 180.f)));
	CObj::Update_Rect();
	return 0;
}

void CItem::Render(HDC hDC)
{
	Rectangle(hDC, m_tRect.left, m_tRect.top, m_tRect.right, m_tRect.bottom);
	TCHAR	szBuf[32] = L"������";
	DrawText(hDC, szBuf, lstrlen(szBuf), &m_tRect, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_NOCLIP);
}

void CItem::Release(void)
{
}

void CItem::LateUpdate(void)
{
	if (m_tInfo.fY < 60 || m_tInfo.fY>WINCY - 75 || m_tInfo.fX<60 || m_tInfo.fX>WINCX - 75)
	{
		m_fAngle += 200.f;
		m_iLife--;
		
	}
	if (m_iLife == 0)
		m_bDead = true;
}
