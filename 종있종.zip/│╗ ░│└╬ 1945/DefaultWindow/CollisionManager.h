#pragma once
#include "Obj.h"
class CCollisionManager
{
public:
	CCollisionManager();
	~CCollisionManager();
public:
	static bool Check_Sphere(CObj * pDst, CObj * pSrc);
	static void Collision_Sphere(CObj* Dst, CObj* Src);
};

