#include "stdafx.h"
#include "MainGame.h"
#include "Define.h"
#include "CollisionManager.h"
#include "CollisionMgr.h"
CMainGame::CMainGame()
	: m_pPlayer(nullptr),m_pTheBoss(nullptr), m_pItem(nullptr) ,m_iTheBossCount(1)
{
	ZeroMemory(&CrashRect, sizeof(RECT));
}

CMainGame::~CMainGame()
{
	Release();
}

void CMainGame::Initialize(void)
{
	m_DC = GetDC(g_hWnd);

	if (!m_pPlayer)
	{
		m_pPlayer = new CPlayer;
		m_pPlayer->Initialize();
	}
	if (!m_pMonster)
	{
		m_pMonster = new CMonster;
		m_pMonster->Initialize();
		m_pMonster->Set_Target(m_pPlayer);
	}
	dynamic_cast<CPlayer*>(m_pPlayer)->SetBullet(&m_BulletList);	
	dynamic_cast<CPlayer*>(m_pPlayer)->SetLasor(&m_LasorList);
	if (!m_pEliteMon)
	{
		m_pEliteMon = new CEliteMon;
		m_pEliteMon->Initialize();
		m_pEliteMon->Set_Target(m_pPlayer);
		
	}
dynamic_cast<CEliteMon*>(m_pEliteMon)->SetBullet(&m_EnemyBulletList);

}

void CMainGame::Update(void)
{
	if (!m_pMonster&&!m_pEliteMon&&!m_pTheBoss&&m_iTheBossCount==1)
	{
		m_pTheBoss = new CTheBoss;
		m_pTheBoss->Initialize();
		dynamic_cast<CTheBoss*>(m_pTheBoss)->SetBullet(&m_EnemyBulletList);
		m_iTheBossCount = 0;
		m_pTheBoss->Set_Target(m_pPlayer);
	}
	Key_Input();
	int iResult;
	if (m_pPlayer)
	{
		if (m_pPlayer->Update() == 1)
		{
			Safe_Delete<CObj*>(m_pPlayer);
		}
	}
	list<CObj*>::iterator iter = m_BulletList.begin();
	
	for (iter; iter != m_BulletList.end();)
	{
		
		iResult= (*iter) ->Update();
		if (iResult == 1)
		{
			Safe_Delete(*iter);
			iter = m_BulletList.erase(iter);

		}
		else
			iter++;
	}
	for (list<CObj*>::iterator iter = m_EnemyBulletList.begin(); iter != m_EnemyBulletList.end();)
	{

		iResult = (*iter)->Update();
		if (iResult == 1)
		{
			Safe_Delete(*iter);
			iter = m_EnemyBulletList.erase(iter);

		}
		else
			iter++;
	}
	
	for (list<CObj*>::iterator iter = m_LasorList.begin(); iter != m_LasorList.end();)
	{

		iResult = (*iter)->Update();
		if (iResult == 1)
		{
			Safe_Delete(*iter);
			iter = m_LasorList.erase(iter);

		}
		else
			iter++;
	}
	for (list<CObj*>::iterator iter = m_ItemList.begin(); iter != m_ItemList.end();)
	{

		iResult = (*iter)->Update();
		if (iResult == 1)
		{
			Safe_Delete(*iter);
			iter = m_ItemList.erase(iter);

		}
		else
			iter++;
	}
	if (m_pMonster)
	{
		if (m_pMonster->Update() == 1)
		{
			Safe_Delete<CObj*>(m_pMonster);
		}
	}
	if (m_pEliteMon)
	{
		if (m_pEliteMon->Update() == 1)
		{
			m_pItem = new CItem;
			m_pItem->Initialize(); 
			m_pItem->SetPos(m_pEliteMon->Get_Info().fX, m_pEliteMon->Get_Info().fY);
			m_ItemList.push_back(m_pItem);
			Safe_Delete<CObj*>(m_pEliteMon);
		}
	}
	if (m_pTheBoss)
	{
		if (m_pTheBoss->Update() == 1)
		{
			m_pItem = new CItem;
			m_pItem->Initialize();
			m_pItem->SetPos(m_pTheBoss->Get_Info().fX, m_pTheBoss->Get_Info().fY);
			m_ItemList.push_back(m_pItem);
			Safe_Delete<CObj*>(m_pTheBoss);
		}
	}
	

}

void CMainGame::LateUpdate(void)
{
	if (m_pMonster)
	{
		m_pMonster->LateUpdate();
		if (m_pPlayer)
		{
			CCollisionManager::Collision_Sphere(m_pPlayer, m_pMonster);
		
		}
		for (auto iter = m_BulletList.begin(); iter != m_BulletList.end();iter++)
	{
	

			CCollisionManager::Collision_Sphere(*iter, m_pMonster);
			
		}
		
			for (auto iter = m_LasorList.begin(); iter != m_LasorList.end(); iter++)
			{


				CCollisionMgr::Collision_Rect(m_pMonster, *iter);

			}
	}
	if (m_pPlayer)
	{
		for (auto iter = m_EnemyBulletList.begin(); iter != m_EnemyBulletList.end(); iter++)
		{


			CCollisionManager::Collision_Sphere(*iter, m_pPlayer);

		}
		for (auto iter = m_ItemList.begin(); iter != m_ItemList.end(); iter++)
		{


			if (CCollisionMgr::Collision_Rect(*iter, m_pPlayer))
				dynamic_cast<CPlayer*>(m_pPlayer)->Set_Lasor();

		}
		
	}
	if (m_pEliteMon)
	{
		m_pEliteMon->LateUpdate();
		if (m_pPlayer)
		{
			CCollisionManager::Collision_Sphere(m_pPlayer, m_pEliteMon);
		}
		for (auto iter = m_BulletList.begin(); iter != m_BulletList.end(); iter++)
		{


			CCollisionManager::Collision_Sphere(*iter, m_pEliteMon);

		}
	
			for (auto iter = m_LasorList.begin(); iter != m_LasorList.end(); iter++)
			{

				CCollisionMgr::Collision_Rect(m_pEliteMon, *iter);
			

			}
	}
	if (m_pTheBoss)
	{
		m_pTheBoss->LateUpdate();
		if (m_pPlayer)
		{
			CCollisionManager::Collision_Sphere(m_pPlayer, m_pTheBoss);
		}
		for (auto iter = m_BulletList.begin(); iter != m_BulletList.end(); iter++)
		{


			CCollisionManager::Collision_Sphere(*iter, m_pTheBoss);

		}
			for (auto iter = m_LasorList.begin(); iter != m_LasorList.end(); iter++)
			{


				CCollisionMgr::Collision_Rect( m_pTheBoss, *iter );

			}
	}
	
	for (auto& iter : m_EnemyBulletList)
	{
		iter->LateUpdate();
	}
	for (auto& iter : m_ItemList)
	{
		iter->LateUpdate();
	}
	
		for (auto& iter : m_LasorList)
		{
			iter->LateUpdate();
		}
	for (auto& iter : m_BulletList)
	{
		iter->LateUpdate();
	}
	if (m_pPlayer)
	{
		m_pPlayer->LateUpdate();
	}
	
	
	
}

void CMainGame::Render()
{
	Rectangle(m_DC, 0, 0, WINCX, WINCY);
	Rectangle(m_DC, 50, 50, WINCX-50, WINCY-50);
	RECT Building{ 200 ,200,330,330 };
	
	TCHAR	szBuf[64] = L"�Ǧ�������������������������������������������������������������������������������������������������������������";
	DrawText(m_DC, szBuf, lstrlen(szBuf), &Building, DT_CENTER | DT_VCENTER  | DT_WORDBREAK);
	RECT Building2{ 500 ,400,630,530 };
	
	DrawText(m_DC, szBuf, lstrlen(szBuf), &Building2, DT_CENTER | DT_VCENTER | DT_WORDBREAK);
	for (auto& iter : m_BulletList)
		iter->Render(m_DC);

	if (m_pPlayer)
	{
		m_pPlayer->Render(m_DC);
	}
	if (m_pMonster) {
		m_pMonster->Render(m_DC);
	}
	if (m_pEliteMon) {
		m_pEliteMon->Render(m_DC);
	}
	if (m_pTheBoss) {
			m_pTheBoss->Render(m_DC);
		}
	for (auto& iter : m_EnemyBulletList)
	iter->Render(m_DC); 
	for (auto& iter : m_ItemList)
		iter->Render(m_DC);
	for (auto& iter : m_LasorList)
	iter->Render(m_DC);
		
}

void CMainGame::Release(void)
{
	Safe_Delete<CObj*>(m_pPlayer);
	
	for_each(m_BulletList.begin(), m_BulletList.end(), CDelete_Obj());
	ReleaseDC(g_hWnd, m_DC);
	if(m_pMonster!= nullptr)
		Safe_Delete<CObj*>(m_pMonster);
	if (m_pEliteMon != nullptr)
		Safe_Delete<CObj*>(m_pEliteMon);	
}

