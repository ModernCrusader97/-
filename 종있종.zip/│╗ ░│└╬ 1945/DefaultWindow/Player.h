#pragma once
#include "Obj.h"
class CPlayer :	public CObj
{
public:
	CPlayer();
	virtual ~CPlayer();
public:
	// CObj��(��) ���� ��ӵ�
	virtual void Initialize(void) override;
	virtual int Update(void) override;
	virtual void Render(HDC hDC) override;
	virtual void Release(void) override;
	void SetBullet(list<CObj*>* pBullet) { m_pBullet = pBullet; }
	void SetLasor(list<CObj*>* pBullet) { m_pLasor = pBullet; }
	CObj* CreateBullet();
	void Set_Lasor() { m_iLasorUpgrade++; }
	CObj * CreateLasor(int _R);
private:
	void	Key_Input(void);
	list<CObj*>* m_pBullet;
	list<CObj*>* m_pLasor;

	POINT		m_tBarrel;
	float m_fDistance;
	// CObj��(��) ���� ��ӵ�
	virtual void LateUpdate(void) override;
	int m_iFireRate;
	int m_iLasorRate;
	int m_iLasorUpgrade;
};

