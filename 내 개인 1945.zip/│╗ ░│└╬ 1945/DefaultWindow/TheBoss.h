#pragma once
#include "Monster.h"
class CTheBoss :
	public CMonster
{
public:
	CTheBoss();
	~CTheBoss();
	void Initialize(void);
	void Render(HDC hDC);
	int Update(void);
	void LateUpdate(void);
	CObj * CreateBullet(int Hand);
	void SetBullet(list<CObj*>* pBullet) { m_pBullet = pBullet; }
	list<CObj*>* m_pBullet;
private:
	int m_iFireRate;
	int m_iFireLimit;
	int m_iTermbetweenAttack;
};


