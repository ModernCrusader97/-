#pragma once
#include "Bullet.h"
class Cmissile :
	public CBullet
{
public:
	Cmissile();
	~Cmissile();
	virtual int Update(void) override;
};

