#include "stdafx.h"
#include "CollisionManager.h"


CCollisionManager::CCollisionManager()
{
}


CCollisionManager::~CCollisionManager()
{
}
bool CCollisionManager::Check_Sphere(CObj * pDst, CObj * pSrc)
{
	float	fWidth = fabs(pDst->Get_Info().fX - pSrc->Get_Info().fX);
	float	fHeight = fabs(pDst->Get_Info().fY - pSrc->Get_Info().fY);

	float	fDiagonal = sqrtf(fWidth * fWidth + fHeight * fHeight);

	float	fRadius = (pDst->Get_Info().fCX + pSrc->Get_Info().fCX) * 0.5f;

	return fDiagonal <= fRadius;
}
void CCollisionManager::Collision_Sphere(CObj* Dst, CObj* Src)
{
	
	if (Check_Sphere(Dst, Src))
	{
		Dst->Set_Dead(true);
		Src->Set_Dead(true);
	}
}
