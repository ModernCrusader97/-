#include "stdafx.h"
#include "Cmissile.h"


Cmissile::Cmissile()
{
}


Cmissile::~Cmissile()
{
}

int Cmissile::Update(void)
{
	if (m_bDead == true)
		return 1;
	float	fWidth = 0.f, fHeight = 0.f, fDiagonal = 0.f;
	float	fRadian = 0.f;


	fWidth = m_pTarget->Get_Info().fX - m_tInfo.fX;
	fHeight = m_pTarget->Get_Info().fY - m_tInfo.fY;

	fDiagonal = sqrtf(fWidth * fWidth + fHeight * fHeight);
	fRadian = acosf(fWidth / fDiagonal);
	m_fAngle = fRadian * 180.f / 3.141592f;

	if (m_pTarget->Get_Info().fY > m_tInfo.fY)
		m_fAngle *= -1.f;

	
	
		m_tInfo.fX += m_fSpeed * cosf(m_fAngle * 3.141592f / 180.f);
		m_tInfo.fY -= m_fSpeed * sinf(m_fAngle * 3.141592f / 180.f);

	
	CObj::Update_Rect();
	return 0;
}

	

