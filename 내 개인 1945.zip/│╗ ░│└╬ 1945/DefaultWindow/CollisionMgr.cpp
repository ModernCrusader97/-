#include "stdafx.h"
#include "CollisionMgr.h"


CCollisionMgr::CCollisionMgr()
{
}


CCollisionMgr::~CCollisionMgr()
{
}

bool CCollisionMgr::Collision_Rect(CObj* Dst, CObj* Src)
{
	RECT	rc{};

	
		
		
	if (IntersectRect(&rc, &Dst->Get_Rect(), &(Src->Get_Rect())))
	{
		Dst->Set_Dead(true);
		return true;

	}
	else
		return false;
	
}

void CCollisionMgr::Collision_Sphere(list<CObj*> Dst, list<CObj*> Src)
{
	for (auto& Dest : Dst)
	{
		for (auto& Sour : Src)
		{
			if (Check_Sphere(Dest, Sour))
			{
				Dest->Set_Dead(true);
				Sour->Set_Dead(true);
			}
		}
	}
}

bool CCollisionMgr::Check_Sphere(CObj * pDst, CObj * pSrc)
{
	float	fWidth = fabs(pDst->Get_Info().fX - pSrc->Get_Info().fX);
	float	fHeight = fabs(pDst->Get_Info().fY - pSrc->Get_Info().fY);

	float	fDiagonal = sqrtf(fWidth * fWidth + fHeight * fHeight);

	float	fRadius = (pDst->Get_Info().fCX + pSrc->Get_Info().fCX) * 0.5f;
	
	return fDiagonal <= fRadius;
}
